# BLDC-Hall-Sensor-Controller
Firmware for controlling a nanotec bldc motor with hall effect sensor. This firmware rus on ST Nucleo boards with ihm07m1 expansion board, but you can change ports name for using it with other boards. Thanks to TVZ for some lib shared.
